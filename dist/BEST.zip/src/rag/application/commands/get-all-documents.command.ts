export class GetAllDocumentsCommand {}
